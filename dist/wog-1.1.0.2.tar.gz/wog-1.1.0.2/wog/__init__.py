"""World Of Games

Play some little games, have fun :)


To run the game, just write:
wog.start()
after you imported the package.
"""
from wog.MainGame import start_game as start

