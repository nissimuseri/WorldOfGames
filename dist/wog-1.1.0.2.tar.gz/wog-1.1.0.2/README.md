#World Of Games - Have a fun with some little games.

This is a Package for DevOps course project.

***Usage:***

pip install wog

**in py file:**

from wog import *

wog.start() --> will start the game.
